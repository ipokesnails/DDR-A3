if (GAMESTATE:GetCurrentSong():HasBGChanges() and VideoStage()) then
	PREFSMAN:SetPreference('SongBackgrounds', false)
else
	PREFSMAN:SetPreference('SongBackgrounds', true)
end

--PREFSMAN:SetPreference('SongBackgrounds', true)
GAMESTATE:GetSongOptionsObject("ModsLevel_Preferred"):RandomBGOnly(false)

return Def.ActorFrame {};